import { Pagination } from "react-bootstrap";
import NavScrollExample from "../navBar";
import Pagin from "../pagination";
import Cards from "../movieCards";

export default function Products( ) {
    return<>
        <Pagin/>
    <Cards/>
    </>
}